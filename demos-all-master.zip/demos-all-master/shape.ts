export class shape{
	name1:String="akshay";
	area1:String="hyderabad";
	constructor(){
	console.log(" i am empty"+this.name1+" "+this.area1);
	}
	 noOfSide(name:String):number{
	console.log("no of sides greater than 3 ");
	return 3;
	}
}