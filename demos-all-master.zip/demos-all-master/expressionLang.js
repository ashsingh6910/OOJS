var name1 = "hello";
var x = name1.concat(" world") + " prithvi we have char " + name1.charAt(3) + " at index 3";
console.log(name1);
console.log(x);
