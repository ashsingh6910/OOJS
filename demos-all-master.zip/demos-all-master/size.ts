import {shape} from "./shape";
let obj = new shape();
obj.noOfSide("circle");