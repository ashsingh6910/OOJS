class TypeScriptDemo{
}