var stu = {
    id: 789,
    courseName: "Java",
    name: "",
    isStudent: true,
    fail: null
};
console.log(stu.id + ' ' + stu.name);
