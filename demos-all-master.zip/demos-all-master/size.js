"use strict";
exports.__esModule = true;
var shape_1 = require("./shape");
var obj = new shape_1.shape();
obj.noOfSide("circle");
