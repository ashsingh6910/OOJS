var TypeScriptDemo = /** @class */ (function () {
    function TypeScriptDemo() {
    }
    return TypeScriptDemo;
}());
