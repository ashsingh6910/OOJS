function doIt(a, b, c) {
    if (b === void 0) { b = 7; }
    console.log(a + " " + b + " " + c + " ");
}
doIt(11, 10);
