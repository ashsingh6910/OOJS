var Demo2 = /** @class */ (function () {
    function Demo2() {
    }
    Demo2.prototype.main = function (String, _a, args) {
        sum(10, 20);
    };
    Demo2.prototype.sum = function (int, num1, int, num2) {
        int;
        temp;
        temp = num1 + num2;
        System.out.print("sum of numbers : " + temp);
    };
    return Demo2;
}());
