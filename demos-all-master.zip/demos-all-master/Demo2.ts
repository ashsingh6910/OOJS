class Demo2{
public static void main(String[] args){
sum(10,20);
}
public static void sum(int num1,int num2){
int temp;
temp=num1+num2;
System.out.print("sum of numbers : "+temp);
}
}