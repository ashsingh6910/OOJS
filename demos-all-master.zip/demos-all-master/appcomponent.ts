import { Component } from '@angular/core';

@Component({
    
    selector: 'two',
    templateUrl: 'two-way.component.html',
    
})
export class TwoWayComponent {

    fName:string='admin'
    lName:string='cg'
}
